
/*

  DEBDEMO - demo program for BGI debug driver

  Copyright (c) 1988,89 - Borland International

*/



#include <stdio.h>
#include <graphics.h>
#include <stdlib.h>

int huge Always_One( void )
{
  return( 1 );
}

void main( )
{

  int drv = DETECT, mode = 0, result;

  printf( "BGI Debug Driver Demo  Copyright (c) 1987,1989 Borland International Inc.\n\n");

  installuserdriver( "DEBUG", Always_One );

  initgraph( &drv, &mode, "" );
  result = graphresult();
  printf( "Graphresult = %d\n", result );
  if( result ) exit( result );

  setcolor( 1 );
  bar( 100, 100, 200, 200 );

  setcolor( 2 );
  bar( 100, 100, 200, 200 );

  setcolor( 3 );
  line( 300, 300, 400, 400 );

  setcolor( 4 );
  circle( 10, 10, 30 );

  setcolor( 5 );
  moveto( 10, 10 );
  outtext( "OutText Call 1" );

  setcolor( 6 );
  outtextxy( 20, 20, "OutText Call 2" );

  closegraph();

  printf( "Finished\n" );

}

